package com.example.bookmanager;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private EditText editTitle, editAuthor;
    private Spinner spinnerCategory;
    private CheckBox checkRead;
    private ListView listBooks;
    private Button buttonSave;

    private BookDatabase dbHelper;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializar os componentes do layout
        editTitle = findViewById(R.id.editTitle);
        editAuthor = findViewById(R.id.editAuthor);
        spinnerCategory = findViewById(R.id.spinnerCategory);
        checkRead = findViewById(R.id.checkRead);
        listBooks = findViewById(R.id.listBooks);
        buttonSave = findViewById(R.id.buttonSave);

        // Inicializar o banco de dados
        dbHelper = new BookDatabase(this);

        // Configurar Spinner com categorias
        ArrayAdapter<CharSequence> spinnerAdapter = ArrayAdapter.createFromResource(this,
                R.array.categories, android.R.layout.simple_spinner_item);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(spinnerAdapter);

        // Carregar livros na ListView
        loadBooks();

        // Configurar ação do botão "Salvar"
        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = editTitle.getText().toString().trim();
                String author = editAuthor.getText().toString().trim();
                String category = spinnerCategory.getSelectedItem().toString();
                boolean isRead = checkRead.isChecked();

                if (title.isEmpty() || author.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Título e Autor são obrigatórios!", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Salvar livro no banco de dados
                dbHelper.saveBook(title, author, category, isRead);

                // Limpar os campos de entrada
                editTitle.setText("");
                editAuthor.setText("");
                checkRead.setChecked(false);

                // Atualizar a ListView
                loadBooks();

                Toast.makeText(MainActivity.this, "Livro salvo com sucesso!", Toast.LENGTH_SHORT).show();
            }
        });

        // Configurar ação de clique longo na ListView para excluir livros
        listBooks.setOnItemLongClickListener((parent, view, position, id) -> {
            String selectedBook = adapter.getItem(position);

            // Excluir livro do banco de dados
            dbHelper.deleteBook(selectedBook);

            // Atualizar a ListView
            loadBooks();

            Toast.makeText(MainActivity.this, "Livro excluído!", Toast.LENGTH_SHORT).show();
            return true;
        });
    }

    private void loadBooks() {
        // Obter lista de títulos de livros do banco de dados
        List<String> bookList = dbHelper.getAllBookTitles();

        // Configurar o adapter para exibir os livros na ListView
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, bookList);
        listBooks.setAdapter(adapter);
    }
}
